#pragma once

bool pebble_clay_preview_component_find_truth(void);
